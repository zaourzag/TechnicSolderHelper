﻿#!/bin/sh

sh technicsolderhelper